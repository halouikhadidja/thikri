import 'package:flutter/material.dart';

void main() => runApp(const ThikriApp());

const ink = Color(0xFF234238);
const green = Color(0xFF527568);
const cream = Color(0xFFF7F4EC);
const gold = Color(0xFFC49A52);

class ThikriApp extends StatelessWidget {
  const ThikriApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ذِكري',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: cream,
        colorScheme: ColorScheme.fromSeed(seedColor: ink, surface: cream),
        fontFamily: 'NotoNaskhArabic',
      ),
      home: const HomeScreen(),
    );
  }
}

class Dhikr {
  final String text;
  final String note;
  final int count;
  const Dhikr(this.text, this.note, this.count);
}

const morning = <Dhikr>[
  Dhikr('أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.', 'مرة واحدة', 1),
  Dhikr('اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ.', 'مرة واحدة', 1),
  Dhikr('سُبْحَانَ اللَّهِ وَبِحَمْدِهِ.', 'مائة مرة', 100),
  Dhikr('أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ.', 'مائة مرة', 100),
];

const evening = <Dhikr>[
  Dhikr('أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.', 'مرة واحدة', 1),
  Dhikr('اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ.', 'مرة واحدة', 1),
  Dhikr('سُبْحَانَ اللَّهِ وَبِحَمْدِهِ.', 'مائة مرة', 100),
];

const prayer = <Dhikr>[
  Dhikr('أَسْتَغْفِرُ اللَّهَ.', 'ثلاث مرات', 3),
  Dhikr('اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ.', 'مرة واحدة', 1),
  Dhikr('سُبْحَانَ اللَّهِ.', 'ثلاث وثلاثون مرة', 33),
  Dhikr('الْحَمْدُ لِلَّهِ.', 'ثلاث وثلاثون مرة', 33),
  Dhikr('اللَّهُ أَكْبَرُ.', 'أربع وثلاثون مرة', 34),
];

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  int counter = 0;
  int target = 33;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: cream,
          surfaceTintColor: cream,
          title: const Row(
            children: [
              Icon(Icons.spa_rounded, color: gold, size: 25),
              SizedBox(width: 8),
              Text('ذِكري', style: TextStyle(color: ink, fontSize: 25, fontWeight: FontWeight.bold)),
            ],
          ),
          actions: [
            IconButton(
              tooltip: 'الإعدادات',
              onPressed: () => _showInfo('الإعدادات', 'سنضيف خيارات الوضع الليلي والتنبيهات في الإصدار القادم.'),
              icon: const Icon(Icons.settings_outlined, color: ink),
            ),
          ],
        ),
        body: IndexedStack(
          index: tab,
          children: [
            _home(),
            _categories(),
            _tasbeeh(),
            _favorites(),
          ],
        ),
        bottomNavigationBar: NavigationBar(
          backgroundColor: Colors.white,
          indicatorColor: const Color(0xFFE3EAE4),
          selectedIndex: tab,
          onDestinationSelected: (v) => setState(() => tab = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'الأذكار'),
            NavigationDestination(icon: Icon(Icons.radio_button_checked), label: 'التسبيح'),
            NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'المفضلة'),
          ],
        ),
      ),
    );
  }

  Widget _home() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(25),
            gradient: const LinearGradient(colors: [ink, green], begin: Alignment.topRight, end: Alignment.bottomLeft),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('﴿ أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ ﴾',
                style: TextStyle(color: Colors.white, fontSize: 19, height: 1.8, fontWeight: FontWeight.w600)),
              SizedBox(height: 8),
              Text('اجعل لسانك رطباً بذكر الله', style: TextStyle(color: Color(0xFFE7EDE8), fontSize: 14)),
              SizedBox(height: 12),
              Align(alignment: Alignment.centerLeft, child: Icon(Icons.auto_awesome, color: Color(0xFFE2C58D), size: 30)),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const Text('أذكارك اليومية', style: TextStyle(fontSize: 20, color: ink, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        _categoryTile('أذكار الصباح', 'ابدأ يومك بذكر الله', Icons.wb_sunny_outlined, () => _openDhikr('أذكار الصباح', morning)),
        _categoryTile('أذكار المساء', 'اختم يومك بالذكر والطمأنينة', Icons.nights_stay_outlined, () => _openDhikr('أذكار المساء', evening)),
        _categoryTile('أذكار بعد الصلاة', 'أذكار مأثورة بعد الفريضة', Icons.mosque_outlined, () => _openDhikr('أذكار بعد الصلاة', prayer)),
        _categoryTile('السبحة الإلكترونية', 'سبّح واستغفر مع عدّاد بسيط', Icons.radio_button_checked, () => setState(() => tab = 2)),
        _categoryTile('أدعية من القرآن والسنة', 'أدعية جامعة ومختارة', Icons.volunteer_activism_outlined, () => _showInfo('الأدعية', 'سيُضاف هذا القسم بعد مراجعة نصوص الأدعية ومصادرها.')),
        _categoryTile('أذكار النوم والاستيقاظ', 'لختام يومك وبداية صباحك', Icons.bedtime_outlined, () => _showInfo('أذكار النوم والاستيقاظ', 'سيُضاف هذا القسم في التحديث القادم.')),
      ],
    );
  }

  Widget _categories() => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const Text('الأذكار', style: TextStyle(fontSize: 23, color: ink, fontWeight: FontWeight.bold)),
      const SizedBox(height: 14),
      _categoryTile('أذكار الصباح', 'أذكار مأثورة للصباح', Icons.wb_sunny_outlined, () => _openDhikr('أذكار الصباح', morning)),
      _categoryTile('أذكار المساء', 'أذكار مأثورة للمساء', Icons.nights_stay_outlined, () => _openDhikr('أذكار المساء', evening)),
      _categoryTile('أذكار بعد الصلاة', 'التسبيح والتحميد والتكبير', Icons.mosque_outlined, () => _openDhikr('أذكار بعد الصلاة', prayer)),
      _categoryTile('أذكار النوم والاستيقاظ', 'قريباً', Icons.bedtime_outlined, () => _showInfo('قريباً', 'هذا القسم قيد الإعداد.')),
      _categoryTile('الرقية الشرعية', 'قريباً', Icons.shield_outlined, () => _showInfo('الرقية الشرعية', 'سيُضاف بعد التحقق من النصوص والمصادر.')),
    ],
  );

  Widget _tasbeeh() {
    final remaining = (target - counter).clamp(0, target);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('السبحة الإلكترونية', style: TextStyle(fontSize: 24, color: ink, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            const Text('سُبْحَانَ اللَّهِ وَبِحَمْدِهِ', style: TextStyle(fontSize: 23, color: green, height: 2)),
            const SizedBox(height: 28),
            Container(
              width: 220, height: 220,
              decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white, border: Border.all(color: const Color(0xFFD8C69F), width: 7), boxShadow: const [BoxShadow(color: Color(0x18000000), blurRadius: 18, offset: Offset(0, 8))]),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text('$counter', style: const TextStyle(fontSize: 58, color: ink, fontWeight: FontWeight.bold)),
                Text('المتبقي: $remaining', style: const TextStyle(color: green, fontSize: 15)),
              ]),
            ),
            const SizedBox(height: 26),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: ink, minimumSize: const Size(190, 58), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
              onPressed: () => setState(() { counter++; if (counter == target) _showInfo('أحسنتِ!', 'أكملتِ $target تسبيحة. تقبّل الله منك.'); }),
              child: const Text('تسبيح', style: TextStyle(fontSize: 20)),
            ),
            TextButton.icon(onPressed: () => setState(() => counter = 0), icon: const Icon(Icons.refresh), label: const Text('إعادة العداد')),
            Wrap(spacing: 8, children: [33, 100].map((n) => ChoiceChip(label: Text('$n مرة'), selected: target == n, onSelected: (_) => setState(() { target = n; counter = 0; }))).toList()),
          ],
        ),
      ),
    );
  }


  Widget _favorites() => Center(
    child: Padding(
      padding: const EdgeInsets.all(28),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: const [
        Icon(Icons.favorite_border, color: gold, size: 54),
        SizedBox(height: 14),
        Text('مفضلتك', style: TextStyle(fontSize: 23, color: ink, fontWeight: FontWeight.bold)),
        SizedBox(height: 8),
        Text('يمكنك حفظ الأذكار التي تحب الرجوع إليها هنا في إصدار قادم.', textAlign: TextAlign.center, style: TextStyle(color: green, height: 1.7)),
      ]),
    ),
  );

  Widget _categoryTile(String title, String subtitle, IconData icon, VoidCallback onTap) {
    return Card(
      elevation: 0,
      color: Colors.white,
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Color(0xFFECE8DE))),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
        leading: Container(width: 48, height: 48, decoration: BoxDecoration(color: const Color(0xFFEAF0EA), borderRadius: BorderRadius.circular(15)), child: Icon(icon, color: ink)),
        title: Text(title, style: const TextStyle(color: ink, fontWeight: FontWeight.bold, fontSize: 16)),
        subtitle: Text(subtitle, style: const TextStyle(color: Colors.black54, fontSize: 12)),
        trailing: const Icon(Icons.chevron_left, color: gold),
        onTap: onTap,
      ),
    );
  }

  void _openDhikr(String title, List<Dhikr> list) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => DhikrScreen(title: title, items: list)));
  }

  void _showInfo(String title, String message) {
    showDialog(context: context, builder: (_) => AlertDialog(
      title: Text(title, textAlign: TextAlign.right, style: const TextStyle(color: ink)),
      content: Text(message, textAlign: TextAlign.right),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('حسناً'))],
    ));
  }
}

class DhikrScreen extends StatefulWidget {
  final String title;
  final List<Dhikr> items;
  const DhikrScreen({super.key, required this.title, required this.items});

  @override
  State<DhikrScreen> createState() => _DhikrScreenState();
}

class _DhikrScreenState extends State<DhikrScreen> {
  late List<int> counts;

  @override
  void initState() {
    super.initState();
    counts = widget.items.map((e) => e.count).toList();
  }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: Text(widget.title, style: const TextStyle(color: ink, fontWeight: FontWeight.bold)), backgroundColor: cream),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: widget.items.length,
        itemBuilder: (context, i) {
          final item = widget.items[i];
          final done = counts[i] == 0;
          return Card(
            elevation: 0,
            color: Colors.white,
            margin: const EdgeInsets.only(bottom: 13),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Color(0xFFECE8DE))),
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Text(item.text, style: const TextStyle(fontSize: 20, height: 2, color: ink)),
                const SizedBox(height: 12),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text(done ? 'تمّ الذكر' : '${item.note} • المتبقي ${counts[i]}', style: const TextStyle(color: green)),
                  FilledButton.tonal(
                    onPressed: done ? null : () => setState(() => counts[i]--),
                    child: Text(done ? 'اكتمل' : 'تسبيح'),
                  ),
                ]),
              ]),
            ),
          );
        },
      ),
    ),
  );
}
